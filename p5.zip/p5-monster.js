//Required code modules
//const Monster = require("./p5-monster-game.js")


const randomRange = (min, max) => Math.floor(Math.random() * (max+1 - min) + min)


/* Monster game class */
/*Constructor expects an object*/

// try 1
/*
class Monsters {
    constructor(name){
        this.name = name
    }
}
let monsterOne = new Monsters('Donkey Kong');
let monsterTwo = new Monsters('Baby Zilla');
let monsterThree = new Monsters('Charizard');

console.log(monsterOne);
console.log(monsterTwo);
console.log(monsterThree);
*/

// try 2

class Monster {
    constructor({monsterName = "unknown", minimumLife = 0, currentLife, isAlive}){
            this.monsterName = monsterName;
            
            minimumLife = minimumLife || 0; 
            this.minimumLife = minimumLife || 0;
            
            this.currentLife = currentLife || 100;
            
            this.isAlive = currentLife >= minimumLife;
    }
    updateLife(lifeChangeAmount) {
        this.currentLife = Math.max(this.currentLife + lifeChangeAmount, 0)
        //this.isAlive = this.currentLife < this.minimumLife
        this.isAlive = this.currentLife >= this.minimumLife
    }

    randomLifeDrain(minimumLifeDrain, maximumLifeDrain){
        let drain = randomRange(minimumLifeDrain, maximumLifeDrain)
        console.log(`${this.monsterName} random power drain ${drain}`)
        this.updateLife(-drain)
    }
}

//let godzilla = new Monsters("Godzilla", 7, 25, true)
//console.log(godzilla)
//console.log(new Monsters())
/*
let i = 100
while (i --> 0) {
godzilla.randomLifeDrain(-10, 5)
console.log(godzilla)
}
*/
//updateLife()

//randomLifeDrain()
/*
let monsterOne = new Monsters('Donkey Kong',);
let monsterTwo = new Monsters('Baby Zilla');
let monsterThree = new Monsters('Charizard');
*/

module.exports = {
    Monster
}